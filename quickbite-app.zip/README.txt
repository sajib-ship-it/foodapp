Quick Bite: installable app package (PWA)

1) Put every file in this folder on any HTTPS static host
   (Netlify Drop, GitHub Pages, Cloudflare Pages, Vercel).
2) Open the URL on your phone:
   - Android Chrome: menu > Install app
   - iPhone Safari: Share > Add to Home Screen
   It then opens full screen with its own icon and works offline.
3) For an APK / Play Store file: go to pwabuilder.com, paste your
   hosted URL, choose Android, and download the package it generates.

Note: this is a front-end demo (sample menu, no real payments or backend).
